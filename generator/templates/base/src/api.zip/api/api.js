/*
  模板默认网络模块，api管理文件
  新增api请遵循格式进行增删
  add by zxy at 2019-03-14 17:19:18
*/
export default {
	/*
	示例如下
    // 获取验证码 
    loginUrl: '/api/xx', 
    // 保险公司以及保险险种查询
    wxOpenLoginUrl:'/api/xxxx'
    */
}